import BookingDetail from '../features/bookings/BookingDetail';

function Booking() {
  return <BookingDetail />;
}

export default Booking;
